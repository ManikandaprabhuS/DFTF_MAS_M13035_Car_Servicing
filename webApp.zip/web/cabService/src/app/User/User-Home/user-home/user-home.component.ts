import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';

@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.css']
})
export class UserHomeComponent implements OnInit {
  user:User=new User();
  successMessage:any;
  userfields:any;
  userDetails:any;
  constructor(private router:Router) {
    this.userfields=localStorage.getItem("user");
       console.log(this.userfields);
    this.userDetails=JSON.parse(this.userfields);
    console.log(this.userDetails.firstName);
   } 

  ngOnInit(): void {
  }

  onLogout(){
    localStorage.removeItem('user');
    this.router.navigate(['/home']);
  }
  
  IsUserIsAuthenticated(){
    if(localStorage.getItem("user")){
      //  this.userDetails=localStorage.getItem("user");
      //  console.log(this.userDetails);
      return true;
    }
    this.router.navigate(['/home']);
    return false;
  }

  }

