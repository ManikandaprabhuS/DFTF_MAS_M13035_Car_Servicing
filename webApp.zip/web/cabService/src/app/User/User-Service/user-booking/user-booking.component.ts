import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RequestServices } from 'src/app/model/request-services';
import { User } from 'src/app/model/user';
import { UserservicesService } from '../../Service/userservices.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-user-booking',
  templateUrl: './user-booking.component.html',
  styleUrls: ['./user-booking.component.css'],
  providers:[DatePipe]
})
export class UserBookingComponent implements OnInit {
  user: User = new User();
  requestService:RequestServices= new RequestServices();
  userfields:any;
  userDetails: any;
  currentDate:any=new Date();

  constructor(private router:Router,
    private vehicleService:UserservicesService, private datapie:DatePipe) {
    this.userfields=localStorage.getItem("user");
    this.currentDate=this.datapie.transform(this.currentDate,'yyyy-MM-dd');
    console.log(this.userfields);
 this.userDetails=JSON.parse(this.userfields);
 console.log(this.userDetails.id);
   }

  ngOnInit(): void {
  }

  userBookService(){
    console.log(this.user);
    this.requestService.userId=this.userDetails.id;
    this.requestService.bookedDate=this.currentDate;
    this.requestService.userFirstName=this.userDetails.firstName;
    this.requestService.serviceStatus="pending";
    this.requestService.estimatedCost="1000";
    this.vehicleService.UserBookService(this.requestService).subscribe(data =>{
      console.log(data);
      this.goToPendindList();
    })
    console.log(alert("Booked service"));
  }
  goToPendindList(){
    this.router.navigate(['/pendingstatus']);
  }

  onLogout(){
    localStorage.removeItem('user');
    this.router.navigate(['/home']);
  }
  
  IsUserIsAuthenticated(){
    if(localStorage.getItem("user")){
      //  this.userDetails=localStorage.getItem("user");
      //  console.log(this.userDetails);
      return true;
    }
    this.router.navigate(['/home']);
    return false;
  }

  onSubmit(){
    console.log(this.requestService);
    this.userBookService();
  }
  
}
