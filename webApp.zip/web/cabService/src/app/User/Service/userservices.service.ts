import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RequestServices } from 'src/app/model/request-services';
import { Vehicle } from 'src/app/model/vehicle';

@Injectable({
  providedIn: 'root'
})
export class UserservicesService {
private baseURLAddVehicle="http://localhost:7447/api/v/vehicle";
private baseURLVehicleList="http://localhost:7447/api/v/vehicle";
private baseURLPendingRequestServiceList="http://localhost:7446/api/sr/pendingrequest";
private baseURLBookService="http://localhost:7446/api/sr/servicerequest";
private baseURlGetAllPendingList="http://localhost:7446/api/sr/servicerequests";

constructor(private httpClient:  HttpClient) { }

UserAddVehicle(vehicle:Vehicle):Observable<object>{
 console.log(vehicle);
  return this.httpClient.post(`${this.baseURLAddVehicle}`,vehicle);
}

getVehicleListByUserId(userId:number):Observable<Vehicle[]>{
  return this.httpClient.get<Vehicle[]>(`${this.baseURLVehicleList}/${userId}`);
}

getpendingRequestListById(userId:number):Observable<RequestServices[]>{
  return this.httpClient.get<RequestServices[]>(`${this.baseURLPendingRequestServiceList}/+${userId}`);
}

UserBookService(requestService:RequestServices):Observable<object>{
  return this.httpClient.post(`${this.baseURLBookService}`,requestService);
}
getAllPendingrequestList():Observable<RequestServices[]>{
  return this.httpClient.get<RequestServices[]>(`${this.baseURlGetAllPendingList}`);
}

}
