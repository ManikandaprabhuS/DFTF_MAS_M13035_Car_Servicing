import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsermyvehicleComponent } from './usermyvehicle.component';

describe('UsermyvehicleComponent', () => {
  let component: UsermyvehicleComponent;
  let fixture: ComponentFixture<UsermyvehicleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsermyvehicleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UsermyvehicleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
