import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { Vehicle } from 'src/app/model/vehicle';
import { UserservicesService } from '../Service/userservices.service';

@Component({
  selector: 'app-usermyvehicle',
  templateUrl: './usermyvehicle.component.html',
  styleUrls: ['./usermyvehicle.component.css']
})
export class UsermyvehicleComponent implements OnInit {
  user:User=new User();
  vehicles:Vehicle=new Vehicle();
  vehiclesArray:Vehicle[]=[];
  userfields:any;
  userDetails: any;
  constructor(private router:Router,
    private userService:UserservicesService) { 
      this.userfields=localStorage.getItem("user");
      console.log(this.userfields);
   this.userDetails=JSON.parse(this.userfields);
   //console.log(this.userDetails.firstName);
    }
  

  ngOnInit(): void {
    this.getvehicleList(this.userDetails.id);
  }

  getvehicleList(userId:number){
    this.userService.getVehicleListByUserId(userId).subscribe(data =>{
      console.log(typeof(data));
      
      this.vehiclesArray=data;
     // this.vehiclesArray.push(this.vehicles);

      console.log(this.vehiclesArray);
    });
  }
 
  onLogout(){
    localStorage.removeItem('user');
    this.router.navigate(['/home']);
  }

  IsUserIsAuthenticated(){
    if(localStorage.getItem("user")){
      return true;
    }
    this.router.navigate(['/home']);
    return false;
  }

}
