import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RequestServices } from 'src/app/model/request-services';
import { User } from 'src/app/model/user';
import { UserservicesService } from '../Service/userservices.service';

@Component({
  selector: 'app-user-pending',
  templateUrl: './user-pending.component.html',
  styleUrls: ['./user-pending.component.css']
})
export class UserPendingComponent implements OnInit {
  user:User=new User();
  services:RequestServices=new RequestServices();
  serviceList:RequestServices[]=[];
  userfields:any;
  userDetails: any;
  constructor(private router:Router,
    private userService:UserservicesService) {
      this.userfields=localStorage.getItem("user");
      console.log(this.userfields);
   this.userDetails=JSON.parse(this.userfields);
   //console.log(this.userDetails.firstName);
     }

  ngOnInit(): void {
    this.getPendingList(this.userDetails.id);
  }
  getPendingList(userId: number) {
    this.userService.getpendingRequestListById(userId).subscribe(data =>{
      console.log(data);
      
      this.serviceList=data;
      //this.serviceList.push(this.services);
      console.log(this.serviceList);
    })
  }

  onLogout(){
    localStorage.removeItem('user');
    this.router.navigate(['/home']);
  }

  IsUserIsAuthenticated(){
    if(localStorage.getItem("user")){
      return true;
    }
    this.router.navigate(['/home']);
    return false;
  }
}


