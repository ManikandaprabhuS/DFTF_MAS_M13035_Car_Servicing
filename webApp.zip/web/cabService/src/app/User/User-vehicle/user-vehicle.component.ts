import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { Vehicle } from 'src/app/model/vehicle';
import { UserservicesService } from '../Service/userservices.service';

@Component({
  selector: 'app-user-vehicle',
  templateUrl: './user-vehicle.component.html',
  styleUrls: ['./user-vehicle.component.css']
})
export class UserVehicleComponent implements OnInit {
  user:User= new User();
  vehicle:Vehicle=new Vehicle();
  userfields:any;
  userDetails: any;
  
  constructor(private router:Router,
    private vehicleService:UserservicesService) {
      this.userfields=localStorage.getItem("user");
      console.log(this.userfields);
   this.userDetails=JSON.parse(this.userfields);
   console.log(this.userDetails.id);
  }
  

  ngOnInit(): void {
  }
  addvehicle(){
    this.vehicle.userId=this.userDetails.id;
    this.vehicleService.UserAddVehicle(this.vehicle).subscribe(data =>{
      console.log(data);
      this.goToUserVehicle();
    })
    console.log(alert("successfully added vehicle"));
  }
  goToUserVehicle(){
this.router.navigate(['/myuservehicle']);
  }

  onSubmit(){
    
    // let userDetails=localStorage.getItem('user');
    // console.log(userDetails);
    console.log(this.vehicle);
    this.addvehicle();
  }

}
