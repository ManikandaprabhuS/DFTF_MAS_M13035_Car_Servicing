import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RequestServices } from 'src/app/model/request-services';
import { User } from 'src/app/model/user';
import { UserservicesService } from '../Service/userservices.service';

@Component({
  selector: 'app-mystatus',
  templateUrl: './mystatus.component.html',
  styleUrls: ['./mystatus.component.css']
})
export class MystatusComponent implements OnInit {
  userfields:any;
  userDetails: any;
  user:User=new User();
  services:RequestServices=new RequestServices();
  serviceList:RequestServices[]=[];

  constructor(private router:Router,
    private userService:UserservicesService) {
    this.userfields=localStorage.getItem("user");
      console.log(this.userfields);
   this.userDetails=JSON.parse(this.userfields);
   }

  ngOnInit(): void {
    this.getPendingList(this.userDetails.id);
  }
  getPendingList(userId: number) {
    this.userService.getpendingRequestListById(userId).subscribe(data =>{
      console.log(data);
      this.serviceList=data;
      //this.serviceList.push(this.services);
      console.log(this.serviceList);
    })
  
  }
  onLogout(){
    localStorage.removeItem('user');
    this.router.navigate(['/home']);
    
  }

  IsUserIsAuthenticated(){
    if(localStorage.getItem("user")){
      return true;
    }
    this.router.navigate(['/home']);
    return false;
  }
}
