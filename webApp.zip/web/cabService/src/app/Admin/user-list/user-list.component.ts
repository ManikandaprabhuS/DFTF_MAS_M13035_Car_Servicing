import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { AdminServicesService } from '../adminService/admin-services.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  userListArray:User[]=[];

  constructor(private router:Router,
    private adminuserlist:AdminServicesService) { }

  ngOnInit(): void {
    this.getAllUserDetails();
  }
  getAllUserDetails(){
    this.adminuserlist.getAllUserList().subscribe(data=>{
      console.log(data);
      this.userListArray=data;
    })
  }
  onLogout(){
    localStorage.removeItem('user');
    this.router.navigate(['/home']);
  }

  IsUserIsAuthenticated(){
    if(localStorage.getItem("user")){
      return true;
    }
    this.router.navigate(['/home']);
    return false;
  }


}
