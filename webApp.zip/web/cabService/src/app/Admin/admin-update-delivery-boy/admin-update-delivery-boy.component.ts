import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DeliveryBoyDetails } from 'src/app/model/delivery-boy-details';
import { AdminServicesService } from '../adminService/admin-services.service';

@Component({
  selector: 'app-admin-update-delivery-boy',
  templateUrl: './admin-update-delivery-boy.component.html',
  styleUrls: ['./admin-update-delivery-boy.component.css']
})
export class AdminUpdateDeliveryBoyComponent implements OnInit {
  deliveryBoys:DeliveryBoyDetails=new DeliveryBoyDetails();
  deliveryBoyId:number=0;
  constructor(private router:Router,
    private route:ActivatedRoute,
    private admindeliveryService:AdminServicesService ) { }

  ngOnInit(): void {
    this.deliveryBoyId=this.route.snapshot.params['deliveryBoyId'];
    this.admindeliveryService.getdeliveryBoydetailsById(this.deliveryBoyId).subscribe(data =>{
      console.log(data);
      this.deliveryBoys=data;
    },
    error=> console.error(error)
    );
  }

  onSubmit(){
    this.admindeliveryService.updateDelieveryBoyById(this.deliveryBoyId,this.deliveryBoys).subscribe(data =>{
      this.router.navigate(['/adminDeliveryList']);
    })
  }

  onLogout() {
    localStorage.removeItem('user');
    console.log(localStorage.clear());
    this.router.navigate(['/home']);
  }
}
