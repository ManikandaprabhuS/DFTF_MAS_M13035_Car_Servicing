import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddcarcenterComponent } from './addcarcenter.component';

describe('AddcarcenterComponent', () => {
  let component: AddcarcenterComponent;
  let fixture: ComponentFixture<AddcarcenterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddcarcenterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddcarcenterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
