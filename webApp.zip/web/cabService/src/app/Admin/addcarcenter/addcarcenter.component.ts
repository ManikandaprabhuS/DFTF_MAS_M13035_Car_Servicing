import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Carcenter } from 'src/app/model/carcenter';
import { AdminServicesService } from '../adminService/admin-services.service';
import { CarcenterServiceService } from '../adminService/carcenter-service.service';


@Component({
  selector: 'app-addcarcenter',
  templateUrl: './addcarcenter.component.html',
  styleUrls: ['./addcarcenter.component.css']
})
export class AddcarcenterComponent implements OnInit {

  carcenterDetails:Carcenter= new  Carcenter();
  constructor(private router:Router,private adminaddService:AdminServicesService) { }

  ngOnInit(): void {
  }
  
  saveCarcenter(){
  this.adminaddService.addCarcenter(this.carcenterDetails).subscribe(data=>{
    console.log(data);
    this.goTOCarcenterList();
  })
  }
  goTOCarcenterList(){
    this.router.navigate(['/carcenterList']);
  }
  onSubmit(){
    console.log(this.carcenterDetails);
    this.saveCarcenter();
  }
  onLogout() {
    localStorage.removeItem('user');
    console.log(localStorage.clear());
    this.router.navigate(['/home']);
  }



}
