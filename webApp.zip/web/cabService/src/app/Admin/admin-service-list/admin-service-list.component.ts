import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RequestServices } from 'src/app/model/request-services';
import { AdminServicesService } from '../adminService/admin-services.service';
import { CarServiceService } from '../adminService/car-service.service';

@Component({
  selector: 'app-admin-service-list',
  templateUrl: './admin-service-list.component.html',
  styleUrls: ['./admin-service-list.component.css']
})
export class AdminServiceListComponent implements OnInit {

  serviceListArray:RequestServices[]=[];

  constructor(private adminServiceList:AdminServicesService,
    private router:Router) { }

  ngOnInit(): void {
    this.getAllServiceList();
  }
  getAllServiceList(){
    this.adminServiceList.getAllServiceList().subscribe(data=>{
      console.log(data);
      this.serviceListArray=data;
    })

  }
  
  onLogout() {
    localStorage.removeItem('user');
    console.log(localStorage.clear());
    this.router.navigate(['/home']);
  }
  


}
