import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminDeliveryboyListComponent } from './admin-deliveryboy-list.component';

describe('AdminDeliveryboyListComponent', () => {
  let component: AdminDeliveryboyListComponent;
  let fixture: ComponentFixture<AdminDeliveryboyListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminDeliveryboyListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminDeliveryboyListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
