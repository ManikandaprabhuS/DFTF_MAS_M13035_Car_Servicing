import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DeliveryBoyDetails } from 'src/app/model/delivery-boy-details';
import { AdminServicesService } from '../adminService/admin-services.service';

@Component({
  selector: 'app-admin-deliveryboy-list',
  templateUrl: './admin-deliveryboy-list.component.html',
  styleUrls: ['./admin-deliveryboy-list.component.css']
})
export class AdminDeliveryboyListComponent implements OnInit {
deliveryboysArray:DeliveryBoyDetails[]=[];

  constructor(private router:Router, 
    private admindeliveryService:AdminServicesService ) { }

  ngOnInit(): void {
    this.getdeliveryBoysList();
  }
  getdeliveryBoysList(){
    this.admindeliveryService.getAllDeliveryBoyDetails().subscribe(data =>{
      console.log(data)
      this.deliveryboysArray=data;
    })

  }
  updatedeliveryBoys(deliveryBoyId:number){
    console.log(deliveryBoyId);
    this.router.navigate(['updateDeliveryBoy',deliveryBoyId]);

  }
  deletedeliveryBoys(deliveryBoyId:number){ 
  this.admindeliveryService.deleteByDeliveryBoy(deliveryBoyId).subscribe(data =>{
  console.log(data);
  this.getdeliveryBoysList();
})
  }
  onLogout() {
    localStorage.removeItem('user');
    console.log(localStorage.clear());
    this.router.navigate(['/home']);
  }

}
