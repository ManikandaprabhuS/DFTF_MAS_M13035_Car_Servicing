import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DeliveryBoyDetails } from 'src/app/model/delivery-boy-details';
import { AdminServicesService } from '../adminService/admin-services.service';

@Component({
  selector: 'app-admin-deliveryboy-add',
  templateUrl: './admin-deliveryboy-add.component.html',
  styleUrls: ['./admin-deliveryboy-add.component.css']
})
export class AdminDeliveryboyAddComponent implements OnInit {

  deliveryBoysDetails:DeliveryBoyDetails=new DeliveryBoyDetails();

  constructor(private router:Router,private admindeliveryService:AdminServicesService) { }

  ngOnInit(): void {
  }
  addDeliveryBoy(){
    this.admindeliveryService.createDeliveryBoy(this.deliveryBoysDetails).subscribe(data =>{
      console.log(data);
      this.goToDeliveryboyList();
    });

  }
  goToDeliveryboyList(){
  this.router.navigate(['/adminDeliveryList']);
  }

  onSubmit(){
    console.log(this.deliveryBoysDetails);
    this.addDeliveryBoy();
  }
  onLogout() {
    localStorage.removeItem('user');
    console.log(localStorage.clear());
    this.router.navigate(['/home']);
  }

}
