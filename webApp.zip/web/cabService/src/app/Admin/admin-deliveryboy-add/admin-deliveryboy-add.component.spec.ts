import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminDeliveryboyAddComponent } from './admin-deliveryboy-add.component';

describe('AdminDeliveryboyAddComponent', () => {
  let component: AdminDeliveryboyAddComponent;
  let fixture: ComponentFixture<AdminDeliveryboyAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminDeliveryboyAddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminDeliveryboyAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
