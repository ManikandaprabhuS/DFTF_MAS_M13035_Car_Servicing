import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Carcenter } from 'src/app/model/carcenter';

@Injectable({
  providedIn: 'root'
})
export class CarcenterServiceService {
  private baseURL = "http://localhost:7445/api/cc/carcenters";
  constructor(private httpClient: HttpClient) { }

  getCarcenterList(): Observable<Carcenter[]>{
    return this.httpClient.get<Carcenter[]>(`${this.baseURL}`);
  }

  addCarcenter(carcenter:Carcenter):Observable<object> {
    return this.httpClient.post(`${this.baseURL}`,carcenter);
  }

  getcarcenterById(id:number):Observable<Carcenter>{
    return this.httpClient.get<Carcenter>(`${this.baseURL}/${id}`);
  }

  updateCarcenter(id:number,carcenter:Carcenter):Observable<object>{
    return this.httpClient.put(`${this.baseURL}/${id}`,carcenter);
  }
  
  deleteCarcenter(id:number):Observable<object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }
}
