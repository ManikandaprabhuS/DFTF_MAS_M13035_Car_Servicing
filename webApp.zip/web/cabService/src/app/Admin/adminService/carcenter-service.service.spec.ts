import { TestBed } from '@angular/core/testing';

import { CarcenterServiceService } from './carcenter-service.service';

describe('CarcenterServiceService', () => {
  let service: CarcenterServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CarcenterServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
