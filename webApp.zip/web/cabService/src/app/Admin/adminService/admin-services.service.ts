import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Carcenter } from 'src/app/model/carcenter';
import { DeliveryBoyDetails } from 'src/app/model/delivery-boy-details';
import { RequestServices } from 'src/app/model/request-services';
import { User } from 'src/app/model/user';
import { Vehicle } from 'src/app/model/vehicle';

@Injectable({
  providedIn: 'root'
})
export class AdminServicesService {
private baseURLDeliveryBoy="http://localhost:8887/api/dboy/dservice";
private baseURLGetAllDeliveryBoy="http://localhost:8887/api/dboy/dservices";
private baseURLdeleteById="http://localhost:8887/api/dboy/dservices"; 
private baseURlUpdateById="http://localhost:8887/api/dboy/dservices";
private baseURLGetByDeliverybyId="http://localhost:8887/api/dboy/dservices";
private baseURLUpdateStatus="http://localhost:7446/api/sr/servicerequests";
private baseURLforApproveId="http://localhost:7446/api/sr/servicerequests";
private basrURLAddCarCenter="http://localhost:7445/api/cc/carcenter";
private baseURLGetUsers="http://localhost:8888/api/register";
private baseURLGetAllCarcenterList="http://localhost:7445/api/cc/carcenters";
private baseURLGetAllServiceList="http://localhost:7446/api/sr/servicerequests";
private baseURLAddService="http://localhost:7446/api/sr/servicerequest";
private baseURLGivapprove="http://localhost:7446/api/sr/servicerequest";
private baseURlUserapprove="http://localhost:8888/api/registerUser";
private baseURLGetBydeliveryBoyname="http://localhost:8887/api/dboy/dservice";

constructor(private httpClient:  HttpClient) { }

  createDeliveryBoy(deliveryBoy:DeliveryBoyDetails):Observable<object>{
  return this.httpClient.post(`${this.baseURLDeliveryBoy}`,deliveryBoy);
}
getAllDeliveryBoyDetails():Observable<DeliveryBoyDetails[]>{
  return this.httpClient.get<DeliveryBoyDetails[]>(`${this.baseURLGetAllDeliveryBoy}`);
}
getdeliveryBoydetailsById(deliveryBoyId:number):Observable<DeliveryBoyDetails>{
  return this.httpClient.get<DeliveryBoyDetails>(`${this.baseURLGetByDeliverybyId}/${deliveryBoyId}`);
}
deleteByDeliveryBoy(deliveryBoyId:number):Observable<object>{
  return this.httpClient.delete(`${this.baseURLdeleteById}/${deliveryBoyId}`);
}

updateDelieveryBoyById(deliveryBoyId:number,deliveryBoyDetails:DeliveryBoyDetails):Observable<object>{
  return this.httpClient.put(`${this.baseURlUpdateById}/${deliveryBoyId}`,deliveryBoyDetails);
}
updatePendingrequest(requestService:RequestServices):Observable<RequestServices>{
  return this.httpClient.put<RequestServices>(`${this.baseURLUpdateStatus}`,requestService);
}

getPendingServiceId(serviceId:number):Observable<RequestServices>{
  return this.httpClient.get<RequestServices>(`${this.baseURLforApproveId}/${serviceId}`);
}
addCarcenter(carcenter:Carcenter):Observable<object>{
  return this.httpClient.post(`${this.basrURLAddCarCenter}`,carcenter);
}
getAllUserList():Observable<User[]>{
  return this.httpClient.get<User[]>(`${this.baseURLGetUsers}`)
}
getAllcarcenterList():Observable<Carcenter[]>{
  return this.httpClient.get<Carcenter[]>(`${this.baseURLGetAllCarcenterList}`);
}
getAllServiceList():Observable<RequestServices[]>{
  return this.httpClient.get<RequestServices[]>(`${this.baseURLGetAllServiceList}`);
}
createService(requestservice:RequestServices):Observable<object>{
  return this.httpClient.post(`${this.baseURLAddService}`,requestservice);
}
saveApprove(approveRequestservice:RequestServices):Observable<object>{
  return this.httpClient.post(`${this.baseURLGivapprove}`,approveRequestservice);
}
updateuser(updateUser:User):Observable<object>{
  return this.httpClient.post(`${this.baseURlUserapprove}`,updateUser);
}
getdeliveryBoyPhoneNumber(deliveryBoyName:string):Observable<Vehicle>{
  return this.httpClient.get<Vehicle>(`${this.baseURLGetBydeliveryBoyname}/${deliveryBoyName}`);
}

}
