import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RequestServices } from 'src/app/model/request-services';

@Injectable({
  providedIn: 'root'
})
export class CarServiceService {
  private baseURL = "http://localhost:7445/api/sr/servicerequest";

  constructor(private httpClient: HttpClient) { }

  getCarserviceList(): Observable<RequestServices[]>{
    return this.httpClient.get<RequestServices[]>(`${this.baseURL}`);
  }

  addCarservice(carcenter:RequestServices):Observable<object> {
    return this.httpClient.post(`${this.baseURL}`,carcenter);
  }

  getcarserviceById(id:number):Observable<RequestServices>{
    return this.httpClient.get<RequestServices>(`${this.baseURL}/${id}`);
  }

  updateCarservice(id:number,carservice:RequestServices):Observable<object>{
    return this.httpClient.put(`${this.baseURL}/${id}`,carservice);
  }
  
  deleteCarservice(id:number):Observable<object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }


}
