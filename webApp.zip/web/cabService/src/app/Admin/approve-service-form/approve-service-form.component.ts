import { partitionArray } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Carcenter } from 'src/app/model/carcenter';
import { DeliveryBoyDetails } from 'src/app/model/delivery-boy-details';
import { RequestServices } from 'src/app/model/request-services';
import { User } from 'src/app/model/user';
import { AdminServicesService } from '../adminService/admin-services.service';

@Component({
  selector: 'app-approve-service-form',
  templateUrl: './approve-service-form.component.html',
  styleUrls: ['./approve-service-form.component.css']
})
export class ApproveServiceFormComponent implements OnInit {
  user: User = new User();
  serviceId: any;
  approve: RequestServices = new RequestServices();
  getdelivery: DeliveryBoyDetails[] = [];
  carcenterList: Carcenter[] = [];
  approvedList: RequestServices[] = [];
  userDeliveryBoy: any;
  SelectedDeliveryBoy: any;
  selectedCarcenterList: any;
  userCarcenter: any;


  constructor(private router: Router,
    private route: ActivatedRoute,
    private adminapprove: AdminServicesService,
    private admindeliveryService: AdminServicesService,
    private admincarcenterservice: AdminServicesService,
    private adminapproveService: AdminServicesService) { }

  ngOnInit(): void {
    this.serviceId = this.route.snapshot.params['serviceId'];
    this.adminapproveService.getPendingServiceId(this.serviceId).subscribe(data => {
      console.log(data);
      this.approve = data;
      this.getDeliveryDetailsAndCarcenter();
    })
  }

  getDeliveryDetailsAndCarcenter() {
    this.admincarcenterservice.getAllcarcenterList().subscribe(data => {
      console.log(data);
      this.carcenterList = data;
    })
    this.admindeliveryService.getAllDeliveryBoyDetails().subscribe(data => {
      console.log(data);
      this.getdelivery = data;
    })
  }

  selectCarcenter() {
    console.log(this.selectedCarcenterList);
    this.userCarcenter = this.selectedCarcenterList;
  }

  SelectedDeliveryboy() {
    console.log(this.SelectedDeliveryBoy);
    this.userDeliveryBoy = this.SelectedDeliveryBoy;
    // this.adminapprove.getdeliveryBoyPhoneNumber(this.userDeliveryBoy).subscribe(data => {
    //   console.log(data);
    // })
  }


  onSubmit() {
    this.approve.serviceStatus = "approved";
    console.log(this.approve);
    //update service status in servicerequest
    this.approve.carCenterName = this.userCarcenter;
    this.approve.deliveryBoyName = this.userDeliveryBoy;
    this.adminapprove.saveApprove(this.approve).subscribe(data => 
      {
      console.log(data);
      })
    this.user.carCenterName = this.userCarcenter;
    this.user.deliveryBoyName = this.userDeliveryBoy;
    console.log(this.user.deliveryBoyName);
    //update  deliveryBoy in user
    this.adminapprove.updateuser(this.user).subscribe(data =>
       {
      console.log(data);
     })
    this.router.navigate(['/adminhome']);
    console.log(alert("successfully Approved "));
    window.location.reload();
  }

  onLogout() {
    localStorage.removeItem('user');
    console.log(localStorage.clear());
    this.router.navigate(['/home']);
  }
}
