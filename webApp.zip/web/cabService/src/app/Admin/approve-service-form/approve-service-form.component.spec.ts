import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproveServiceFormComponent } from './approve-service-form.component';

describe('ApproveServiceFormComponent', () => {
  let component: ApproveServiceFormComponent;
  let fixture: ComponentFixture<ApproveServiceFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApproveServiceFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproveServiceFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
