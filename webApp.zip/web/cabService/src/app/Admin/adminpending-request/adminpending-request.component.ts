import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { observable } from 'rxjs';
import { RequestServices } from 'src/app/model/request-services';
import { UserservicesService } from 'src/app/User/Service/userservices.service';
import { AdminServicesService } from '../adminService/admin-services.service';

@Component({
  selector: 'app-adminpending-request',
  templateUrl: './adminpending-request.component.html',
  styleUrls: ['./adminpending-request.component.css']
})
export class AdminpendingRequestComponent implements OnInit {
  serviceId:number=0;
  userServicesList:RequestServices[]=[];
  requestService:RequestServices= new RequestServices();
  gettingServiceDetails:any;

  constructor(private userService:UserservicesService,
    private adminService:AdminServicesService,
    private router:Router) { }

  ngOnInit(): void {
    this.getAllpendingRequestList();
  }

  getAllpendingRequestList(){
    this.userService.getAllPendingrequestList().subscribe(data=>{
      console.log(data);
      this.userServicesList=data;
    })
  }
  approverequest(serviceId:number){
    console.log(serviceId);
    this.router.navigate(['approveServiceform',serviceId]);

  }
  rejectServicerequest(serviceId:number){
    this.adminService.getPendingServiceId(serviceId).subscribe(data =>{
      console.log(data);
      this.gettingServiceDetails=data;
      this.gettingServiceDetails.serviceStatus="Rejected";
      //this.requestService.serviceStatus="Rejected";
      console.log(this.gettingServiceDetails);
      this.adminService.updatePendingrequest(this.gettingServiceDetails).subscribe(data=>{
        console.log(data);
      })
    })
    console.log(alert("successfully Rejected"));
    window.location.reload();
  }
  onLogout(){
    localStorage.removeItem('user');
    console.log(localStorage.clear());
    this.router.navigate(['/home']);
  }
}
