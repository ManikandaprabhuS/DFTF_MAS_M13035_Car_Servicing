import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminpendingRequestComponent } from './adminpending-request.component';

describe('AdminpendingRequestComponent', () => {
  let component: AdminpendingRequestComponent;
  let fixture: ComponentFixture<AdminpendingRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminpendingRequestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminpendingRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
