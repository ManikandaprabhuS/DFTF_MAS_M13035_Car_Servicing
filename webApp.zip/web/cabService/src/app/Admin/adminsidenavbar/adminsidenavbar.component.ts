import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminsidenavbar',
  templateUrl: './adminsidenavbar.component.html',
  styleUrls: ['./adminsidenavbar.component.css']
})
export class AdminsidenavbarComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  onLogout(){
    localStorage.removeItem('user');
    console.log(localStorage.clear());
    this.router.navigate(['/home']);
  }
}
