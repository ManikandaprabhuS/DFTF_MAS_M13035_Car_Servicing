import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminsidenavbarComponent } from './adminsidenavbar.component';

describe('AdminsidenavbarComponent', () => {
  let component: AdminsidenavbarComponent;
  let fixture: ComponentFixture<AdminsidenavbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminsidenavbarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminsidenavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
