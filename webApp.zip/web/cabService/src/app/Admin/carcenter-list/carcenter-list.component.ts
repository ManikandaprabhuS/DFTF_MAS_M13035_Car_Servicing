import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Carcenter } from 'src/app/model/carcenter';
import { AdminServicesService } from '../adminService/admin-services.service';
import { CarcenterServiceService } from '../adminService/carcenter-service.service';

@Component({
  selector: 'app-carcenter-list',
  templateUrl: './carcenter-list.component.html',
  styleUrls: ['./carcenter-list.component.css']
})
export class CarcenterListComponent implements OnInit {

  CarcenterListArry:Carcenter[]=[];
  constructor(private router:Router,private carservice:AdminServicesService) { }

  ngOnInit(): void {
    this.getAllcarcenterDetails();

     }
getAllcarcenterDetails(){
  this.carservice.getAllcarcenterList().subscribe(data=>{
    console.log(data);
    this.CarcenterListArry=data;
    
  })
}
onLogout(){
  localStorage.removeItem('user');
  this.router.navigate(['/home']);
}

IsUserIsAuthenticated(){
  if(localStorage.getItem("user")){
    return true;
  }
  this.router.navigate(['/home']);
  return false;
}

}
