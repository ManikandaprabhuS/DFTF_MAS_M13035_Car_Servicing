import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarcenterListComponent } from './carcenter-list.component';

describe('CarcenterListComponent', () => {
  let component: CarcenterListComponent;
  let fixture: ComponentFixture<CarcenterListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CarcenterListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CarcenterListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
