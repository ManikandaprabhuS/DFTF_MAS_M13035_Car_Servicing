import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RequestServices } from 'src/app/model/request-services';
import { AdminServicesService } from '../adminService/admin-services.service';
import { CarServiceService } from '../adminService/car-service.service';

@Component({
  selector: 'app-add-service',
  templateUrl: './add-service.component.html',
  styleUrls: ['./add-service.component.css']
})
export class AddServiceComponent implements OnInit {

  requestservicedetails:RequestServices=new RequestServices();

  constructor(private router:Router,
    private adminaddService:AdminServicesService) { }

  ngOnInit(): void {
  }
  addServiceDetails(){
    this.adminaddService.createService(this.requestservicedetails).subscribe(data =>{
      console.log(data);
      this.goToServiceList();
    })
  }
  goToServiceList(){
    this.router.navigate(['/requestServiceList'])
  }


onSubmit(){
  console.log(this.requestservicedetails);
  this.addServiceDetails();
}
onLogout() {
  localStorage.removeItem('user');
  console.log(localStorage.clear());
  this.router.navigate(['/home']);
}
}
