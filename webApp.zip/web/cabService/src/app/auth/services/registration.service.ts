import {  HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from 'src/app/model/user';

@Injectable({
  providedIn: 'root'
})

export class RegistrationService {
  private baseURLRegister= "http://localhost:8888/api/registerUser";
  private baseURLLogin="http://localhost:8888/api/login";

  constructor(private httpClient:  HttpClient) { }

  createUserRegistration(user:User):Observable<object>{
    console.log(user);
    return this.httpClient.post(`${this.baseURLRegister}`,user);
  }

  loginUser(user:User):Observable<object>{
   // console.log(user);
    return this.httpClient.post(`${this.baseURLLogin}`,user);
  } 

}
