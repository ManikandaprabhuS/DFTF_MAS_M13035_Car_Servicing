import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { RegistrationService } from '../services/registration.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  user: User = new User();

  constructor(private router: Router,
    private registrationService: RegistrationService) { }

  ngOnInit(): void {
  }
  
  registeruser() {
    console.log(this.user);
    this.registrationService.createUserRegistration(this.user).subscribe(data => {
      console.log(data);
      this.goToUserList();
    });
  }
  goToUserList() {
    this.router.navigate(['/login']);
    console.log(alert("successfully loged In"));
  }
  onSubmit() {
    console.log(this.user);
    this.registeruser();
  }
}
