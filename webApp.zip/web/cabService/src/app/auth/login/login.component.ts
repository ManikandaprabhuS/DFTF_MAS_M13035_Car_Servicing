import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { RegistrationService } from '../services/registration.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: User = new User();
  userIsAuthenticated:boolean=false;
  userid:any;
  errorMessage: any;
  constructor(private registrationService: RegistrationService,
     private router: Router) { }

  ngOnInit(): void {
  }
  Login() {
    if(this.user.userId=="admin@admin" && this.user.password=="admin"){
      console.log(this.user);
      this.router.navigate(['/adminhome']);
      localStorage.setItem('user',this.user.userId);
      console.log(alert("successfully loged In"));
    }
     else{
      this.registrationService.loginUser(this.user).subscribe(data =>  {
        console.log(data);
        this.userid=data
        console.log(this.userid.id);
        this.router.navigate(['/userhome']);
        localStorage.setItem('user',JSON.stringify(this.userid));
        console.log(alert("successfully loged In"));
      },
      (error) => {                              //Error callback
        console.error('Not Found')
        this.errorMessage = error;
      }
    );
    }
  }

  onSubmit() {
    this.Login();
  }
  
  IsUserIsAuthenticated(){
    if(localStorage.getItem("user")){
      return true;
    }
    this.router.navigate(['/home']);
    return false;
    
  }
 onLogout(){
  localStorage.removeItem('user');
    this.router.navigate(['/home']);
  }

}
