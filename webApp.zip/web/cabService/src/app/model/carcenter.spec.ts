import { Carcenter } from './carcenter';

describe('Carcenter', () => {
  it('should create an instance', () => {
    expect(new Carcenter()).toBeTruthy();
  });
});
