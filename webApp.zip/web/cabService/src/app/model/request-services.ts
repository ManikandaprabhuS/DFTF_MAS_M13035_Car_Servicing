export class RequestServices {
    serviceId:number=0;
    serviceType:string="";
    serviceStartDate:string="";
    serviceEndDate:string="";
    bookedDate:string="";
    estimatedCost:string="";
    serviceStatus:string="";
    carCenterName:string="";
    deliveryBoyName:string="";
    userId: number=0;
    userFirstName:string="";
}
