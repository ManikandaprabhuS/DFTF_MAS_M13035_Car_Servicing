import { Vehicle } from './vehicle';

describe('Vehicle', () => {
  it('should create an instance', () => {
    expect(new Vehicle()).toBeTruthy();
  });
});
