import { DeliveryBoyDetails } from './delivery-boy-details';

describe('DeliveryBoyDetails', () => {
  it('should create an instance', () => {
    expect(new DeliveryBoyDetails()).toBeTruthy();
  });
});
