export class User {
    id:number=0;
    firstName:string="";
    lastName:string="";
    age:number=0;
    gender:string="";
    contactNumber:string="";
    userId:string="";
    password:string="";
    dateOfBirth:string="";
    serviceId:number=0;
    deliveryBoyName:string="";
    carCenterName:string="";
}
