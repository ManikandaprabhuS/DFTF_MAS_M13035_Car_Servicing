export class Vehicle {
    vehicleId:number=0;
    vehicleName:string="";
    vehicleType:string="";
    vehicleColor:string="";
    userId:number=0;
}
