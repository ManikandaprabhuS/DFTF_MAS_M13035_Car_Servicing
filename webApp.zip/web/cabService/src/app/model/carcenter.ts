export class Carcenter {
    centerId:number=0;
    centerName:string='';
   centerAddress:string='';
   centerAvailability:string='';;
   userId:number=0;
}
