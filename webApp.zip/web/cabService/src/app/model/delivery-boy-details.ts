export class DeliveryBoyDetails {
    deliveryBoyId:number=0;
    deliveryBoyName:string="";
    deliveryBoyNumber:string="";
    userId:number=0;
}
