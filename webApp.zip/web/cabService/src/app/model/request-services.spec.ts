import { RequestServices } from './request-services';

describe('RequestServices', () => {
  it('should create an instance', () => {
    expect(new RequestServices()).toBeTruthy();
  });
});
