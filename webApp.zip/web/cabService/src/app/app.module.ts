import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './auth/login/login.component';
import { RegistrationComponent } from './auth/registration/registration.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { UserHomeComponent } from './User/User-Home/user-home/user-home.component';
import { HomeComponent } from './home/home.component';
import { UserVehicleComponent } from './User/User-vehicle/user-vehicle.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { AdminsidenavbarComponent } from './Admin/adminsidenavbar/adminsidenavbar.component';
import { AdminhomeComponent } from './Admin/adminhome/adminhome.component';
import { AdminDashboardComponent } from './Admin/admin-dashboard/admin-dashboard.component';
import { UsermyvehicleComponent } from './User/usermyvehicle/usermyvehicle.component';
import { UserPendingComponent } from './User/user-pending/user-pending.component';
import { UserBookingComponent } from './User/User-Service/user-booking/user-booking.component';
import { AdminDeliveryboyAddComponent } from './Admin/admin-deliveryboy-add/admin-deliveryboy-add.component';
import { AdminDeliveryboyListComponent } from './Admin/admin-deliveryboy-list/admin-deliveryboy-list.component';
import { AdminpendingRequestComponent } from './Admin/adminpending-request/adminpending-request.component';
import { AdminUpdateDeliveryBoyComponent } from './Admin/admin-update-delivery-boy/admin-update-delivery-boy.component';
import { ApproveServiceFormComponent } from './Admin/approve-service-form/approve-service-form.component';
import { AddcarcenterComponent } from './Admin/addcarcenter/addcarcenter.component';
import { CarcenterListComponent } from './Admin/carcenter-list/carcenter-list.component';
import { AddServiceComponent } from './Admin/add-service/add-service.component';
import { AdminServiceListComponent } from './Admin/admin-service-list/admin-service-list.component';
import { UserListComponent } from './Admin/user-list/user-list.component';
import { MystatusComponent } from './User/mystatus/mystatus.component';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    UserHomeComponent,
    HomeComponent,
    UserVehicleComponent,
    NavbarComponent,
    FooterComponent,
    AdminsidenavbarComponent,
    AdminDashboardComponent,
    AdminhomeComponent,
    UsermyvehicleComponent,
    UserPendingComponent,
    UserBookingComponent,
    AdminDeliveryboyAddComponent,
    AdminDeliveryboyListComponent,
    AdminpendingRequestComponent,
    AdminUpdateDeliveryBoyComponent,
    ApproveServiceFormComponent,
    AddcarcenterComponent,
    CarcenterListComponent,
    AddServiceComponent,
    AdminServiceListComponent,
    UserListComponent,
    MystatusComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
