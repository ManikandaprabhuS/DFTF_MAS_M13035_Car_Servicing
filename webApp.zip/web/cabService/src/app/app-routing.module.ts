import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddServiceComponent } from './Admin/add-service/add-service.component';
import { AddcarcenterComponent } from './Admin/addcarcenter/addcarcenter.component';
import { AdminDashboardComponent } from './Admin/admin-dashboard/admin-dashboard.component';
import { AdminDeliveryboyAddComponent } from './Admin/admin-deliveryboy-add/admin-deliveryboy-add.component';
import { AdminDeliveryboyListComponent } from './Admin/admin-deliveryboy-list/admin-deliveryboy-list.component';
import { AdminServiceListComponent } from './Admin/admin-service-list/admin-service-list.component';
import { AdminUpdateDeliveryBoyComponent } from './Admin/admin-update-delivery-boy/admin-update-delivery-boy.component';
import { AdminhomeComponent } from './Admin/adminhome/adminhome.component';
import { AdminpendingRequestComponent } from './Admin/adminpending-request/adminpending-request.component';
import { ApproveServiceFormComponent } from './Admin/approve-service-form/approve-service-form.component';
import { CarcenterListComponent } from './Admin/carcenter-list/carcenter-list.component';
import { UserListComponent } from './Admin/user-list/user-list.component';
import { LoginComponent } from './auth/login/login.component';
import { RegistrationComponent } from './auth/registration/registration.component';
import { HomeComponent } from './home/home.component';
import { MystatusComponent } from './User/mystatus/mystatus.component';
import { UserHomeComponent } from './User/User-Home/user-home/user-home.component';
import { UserPendingComponent } from './User/user-pending/user-pending.component';
import { UserBookingComponent } from './User/User-Service/user-booking/user-booking.component';
import { UserVehicleComponent } from './User/User-vehicle/user-vehicle.component';
import { UsermyvehicleComponent } from './User/usermyvehicle/usermyvehicle.component';



const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'registerUser',component:RegistrationComponent},
  {path:'home',component:HomeComponent},
  {path:'adminhome',component:AdminhomeComponent},
  {path:'',component:HomeComponent},
  {path:'mystatus',component:MystatusComponent},
  {path:'vehicle',component:UserVehicleComponent},
  {path:'addCarcenters',component:AddcarcenterComponent},
  {path:'adminDeliveryList',component:AdminDeliveryboyListComponent},
  {path:'pendingrequest',component:AdminpendingRequestComponent},
  {path:'updateDeliveryBoy/:deliveryBoyId',component:AdminUpdateDeliveryBoyComponent},
  {path:'adminDashboard',component:AdminDashboardComponent},
  {path:'approveServiceform/:serviceId',component:ApproveServiceFormComponent},
  {path:'userbook',component:UserBookingComponent},
  {path:'carcenterList',component:CarcenterListComponent},
  {path:'addcarservice',component:AddServiceComponent},
  {path:'adddeliveryboy',component:AdminDeliveryboyAddComponent},
  {path:'myuservehicle',component:UsermyvehicleComponent},
  {path:'pendingstatus',component:UserPendingComponent},
  {path:'userhome',component:UserHomeComponent},
  {path:'userList',component:UserListComponent},
  {path:'requestServiceList',component:AdminServiceListComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
