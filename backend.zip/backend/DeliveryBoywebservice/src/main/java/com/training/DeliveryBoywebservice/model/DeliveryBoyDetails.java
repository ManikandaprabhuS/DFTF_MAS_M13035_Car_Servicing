package com.training.DeliveryBoywebservice.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder

public class DeliveryBoyDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int deliveryBoyId;
	private String deliveryBoyName;
	private String deliveryBoyNumber;
	private int userId;
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getDeliveryBoyId() {
		return deliveryBoyId;
	}
	public void setDeliveryBoyId(int deliveryBoyId) {
		this.deliveryBoyId = deliveryBoyId;
	}
	public String getDeliveryBoyName() {
		return deliveryBoyName;
	}
	public void setDeliveryBoyName(String deliveryBoyName) {
		this.deliveryBoyName = deliveryBoyName;
	}
	public String getDeliveryBoyNumber() {
		return deliveryBoyNumber;
	}
	public void setDeliveryBoyNumber(String deliveryBoyNumber) {
		this.deliveryBoyNumber = deliveryBoyNumber;
	}
	
	public DeliveryBoyDetails(int deliveryBoyId, String deliveryBoyName, String deliveryBoyNumber) {
		super();
		this.deliveryBoyId = deliveryBoyId;
		this.deliveryBoyName = deliveryBoyName;
		this.deliveryBoyNumber = deliveryBoyNumber;
	}
	
	public DeliveryBoyDetails(int deliveryBoyId, String deliveryBoyName, String deliveryBoyNumber, int userId) {
		super();
		this.deliveryBoyId = deliveryBoyId;
		this.deliveryBoyName = deliveryBoyName;
		this.deliveryBoyNumber = deliveryBoyNumber;
		this.userId = userId;
	}
	public DeliveryBoyDetails() {
		super();
		
	}
	@Override
	public String toString() {
		return "DeliveryBoyDetails [deliveryBoyId=" + deliveryBoyId + ", deliveryBoyName=" + deliveryBoyName
				+ ", deliveryBoyNumber=" + deliveryBoyNumber + "]";
	}
	
	
}
