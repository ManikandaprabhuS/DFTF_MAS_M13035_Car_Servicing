package com.training.DeliveryBoywebservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.training.DeliveryBoywebservice.model.DeliveryBoyDetails;
@Repository
public interface DeliveryBoyRepository extends JpaRepository<DeliveryBoyDetails, Integer> {

	List<DeliveryBoyDetails> findBydeliveryBoyName(String tempname);

}
