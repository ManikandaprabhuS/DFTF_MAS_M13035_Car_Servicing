package com.training.DeliveryBoywebservice.service;

import java.util.List;

import com.training.DeliveryBoywebservice.model.DeliveryBoyDetails;

public interface DeliveryBoyService {
	
	public List<DeliveryBoyDetails> getfindAllDeliveryBoyDetails();
	public DeliveryBoyDetails saveDeliveryBoyDetails(DeliveryBoyDetails deliveryboy);
	public DeliveryBoyDetails findById(int deliveryBoyId);
	public DeliveryBoyDetails save(DeliveryBoyDetails deliveryboy);
	public boolean delete(int deliveryBoyId);
	public List<DeliveryBoyDetails> findBydeliveryBoyName(String tempname);

}
