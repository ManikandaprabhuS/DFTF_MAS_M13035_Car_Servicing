package com.training.DeliveryBoywebservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.DeliveryBoywebservice.model.DeliveryBoyDetails;
import com.training.DeliveryBoywebservice.repository.DeliveryBoyRepository;
import com.training.DeliveryBoywebservice.service.DeliveryBoyService;

@RestController
@RequestMapping("/api/dboy/")
public class DeliveryBoyController {

	@Autowired
	DeliveryBoyService dService;
	
	@Autowired
	DeliveryBoyRepository dboyRepo;
	
	//get all DeliveryBoyDetails
	@GetMapping("dservices")
	public List<DeliveryBoyDetails> getAllDeliveryBoyDetails(){
		return dService.getfindAllDeliveryBoyDetails();	
	}
	
	//create DeliveryBoyDetails
	@PostMapping("dservice")
	public ResponseEntity<DeliveryBoyDetails> create(@RequestBody DeliveryBoyDetails deliveryboy){
		return new ResponseEntity<DeliveryBoyDetails>( dService.saveDeliveryBoyDetails(deliveryboy),HttpStatus.CREATED);
	}
	
//	//getting userid whose vehicle is
	@GetMapping("dservice/{deliveryBoyName}")
	public ResponseEntity<List<DeliveryBoyDetails>> findBydeliveryBoyName(@PathVariable(value="deliveryBoyName") String deliveryBoyName ){
		String tempname=deliveryBoyName;
		List<DeliveryBoyDetails> deliveryPhoneNumber=dService.findBydeliveryBoyName(tempname);
		System.out.println(deliveryPhoneNumber);
		return new ResponseEntity<List<DeliveryBoyDetails>>(deliveryPhoneNumber,HttpStatus.OK);
}
	
	//get DeliveryBoyDetails By deliveryBoyId
	@GetMapping("dservices/{deliveryBoyId}")
	public ResponseEntity<DeliveryBoyDetails> dservice(@PathVariable int deliveryBoyId){
		DeliveryBoyDetails	deliveryBoyDetailsId=dService.findById(deliveryBoyId);
		return new ResponseEntity<DeliveryBoyDetails>(deliveryBoyDetailsId,HttpStatus.OK) ;
	}
	
	//update DeliveryBoyDetails rest
	@PutMapping("dservices/{deliveryBoyId}")
	public ResponseEntity<DeliveryBoyDetails> update(@PathVariable ("deliveryBoyId") int deliveryBoyId,@RequestBody DeliveryBoyDetails deliveryboy){
		DeliveryBoyDetails dboy=dService.findById(deliveryBoyId);
		dboy.setDeliveryBoyName(deliveryboy.getDeliveryBoyName());
		dboy.setDeliveryBoyNumber(deliveryboy.getDeliveryBoyNumber());
		DeliveryBoyDetails updateDboy=dService.save(dboy);
		System.out.println(updateDboy);
		return new ResponseEntity<DeliveryBoyDetails>(updateDboy,HttpStatus.OK);
	}
	
	//delete DeliveryBoyDetails Rest
	@DeleteMapping("dservices/{deliveryBoyId}")
	public ResponseEntity<Boolean> delete(@PathVariable int deliveryBoyId){
		boolean deleteDboy=dService.delete(deliveryBoyId);
		return new ResponseEntity<Boolean>(deleteDboy,HttpStatus.OK);
	}
}
