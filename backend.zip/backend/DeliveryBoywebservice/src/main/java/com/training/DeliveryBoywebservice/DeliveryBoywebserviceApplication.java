package com.training.DeliveryBoywebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeliveryBoywebserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeliveryBoywebserviceApplication.class, args);
	}

}
