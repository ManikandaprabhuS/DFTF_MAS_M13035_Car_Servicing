package com.training.DeliveryBoywebservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.DeliveryBoywebservice.model.DeliveryBoyDetails;
import com.training.DeliveryBoywebservice.repository.DeliveryBoyRepository;

@Service

public class DeliveryBoyServiceImpl implements DeliveryBoyService {

	
	@Autowired
	DeliveryBoyRepository dboyRepo;
	
	
	@Override
	public List<DeliveryBoyDetails> getfindAllDeliveryBoyDetails() {
		return dboyRepo.findAll();
	}

	@Override
	public DeliveryBoyDetails saveDeliveryBoyDetails(DeliveryBoyDetails deliveryboy) {
		return dboyRepo.save(deliveryboy);
	}

	@Override
	public DeliveryBoyDetails findById(int deliveryBoyId) {
		return dboyRepo.findById(deliveryBoyId).get();
	}

	@Override
	public DeliveryBoyDetails save(DeliveryBoyDetails deliveryboy) {
		return dboyRepo.save(deliveryboy);
	}

	@Override
	public boolean delete(int deliveryBoyId) {
		dboyRepo.deleteById(deliveryBoyId);
		return true;
	}

	@Override
	public List<DeliveryBoyDetails> findBydeliveryBoyName(String tempname) {
		return dboyRepo.findBydeliveryBoyName(tempname);
	}

	
}
