package com.training.DeliveryBoywebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryBoywebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
