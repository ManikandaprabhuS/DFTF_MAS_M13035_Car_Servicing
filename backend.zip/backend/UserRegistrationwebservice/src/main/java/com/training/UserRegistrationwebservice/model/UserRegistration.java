package com.training.UserRegistrationwebservice.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class UserRegistration {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String firstName;
	private String lastName;
	private int age;
	private String gender;
	private String contactNumber;
	@Column(unique=true)
	private String userId;
	private String password;
	private String dateOfBirth;
	private int serviceId;
	private String carCenterName;
	private String deliveryBoyName;

	public String getCarCenterName() {
		return carCenterName;
	}
	public void setCarCenterName(String carCenterName) {
		this.carCenterName = carCenterName;
	}
	public String getDeliveryBoyName() {
		return deliveryBoyName;
	}
	public void setDeliveryBoyName(String deliveryBoyName) {
		this.deliveryBoyName = deliveryBoyName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	
	@Override
	public String toString() {
		return "UserRegistration [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age
				+ ", gender=" + gender + ", contactNumber=" + contactNumber + ", userId=" + userId + ", password="
				+ password + ", dateOfBirth=" + dateOfBirth + ", serviceId=" + serviceId + ", carCenterName="
				+ carCenterName + ", deliveryBoyName=" + deliveryBoyName + "]";
	}
	// for Login purpose i have passing two parameters to backend
	public UserRegistration(String userId, String password) {
		super();
		this.userId = userId;
		this.password = password;
	}
	
	// for register purpose getting All the details and saved in backend
	public UserRegistration(int id, String firstName, String lastName, int age, String gender, String contactNumber,
			String userId, String password, String dateOfBirth) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.gender = gender;
		this.contactNumber = contactNumber;
		this.userId = userId;
		this.password = password;
		this.dateOfBirth = dateOfBirth;
	}
	public UserRegistration(int id, String firstName, String lastName, int age, String gender, String contactNumber,
			String userId, String password, String dateOfBirth, int serviceId,String carCenterName,String deliveryBoyName) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.gender = gender;
		this.contactNumber = contactNumber;
		this.userId = userId;
		this.password = password;
		this.dateOfBirth = dateOfBirth;
		this.serviceId = serviceId;
		this.carCenterName=carCenterName;
		this.deliveryBoyName=deliveryBoyName;
	}
	
	public UserRegistration(int id, String firstName, String lastName) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	
	public UserRegistration() {
		super();
	}
		
	
}
