package com.training.UserRegistrationwebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserRegistrationwebserviceApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(UserRegistrationwebserviceApplication.class, args);
	}

}
