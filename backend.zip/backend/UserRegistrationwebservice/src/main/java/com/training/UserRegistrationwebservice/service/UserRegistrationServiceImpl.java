package com.training.UserRegistrationwebservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.UserRegistrationwebservice.model.UserRegistration;
import com.training.UserRegistrationwebservice.repository.UserRegistrationRepository;

@Service
public class UserRegistrationServiceImpl implements UserRegistrationService {

		@Autowired
		UserRegistrationRepository userRepo;
		
	@Override
	public UserRegistration createUser(UserRegistration user) {
		return userRepo.save(user);
	}

	@Override
	public List<UserRegistration> findAll() {
		return userRepo.findAll();
	}

	@Override
	public UserRegistration userfindById(int id) {
		return userRepo.findById(id).get();
	}

	@Override
	public boolean deleteById(int id) {
		 userRepo.deleteById(id);
		 return true;
	}

	@Override
	public UserRegistration updateUser(UserRegistration user) {
		return userRepo.save(user);
	}


}
