package com.training.UserRegistrationwebservice.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.UserRegistrationwebservice.model.UserRegistration;
import com.training.UserRegistrationwebservice.repository.UserRegistrationRepository;
import com.training.UserRegistrationwebservice.service.UserRegistrationService;

@RestController
@RequestMapping("/api/")
public class UserRegistrationController {

	@Autowired
	UserRegistrationService userService;
	@Autowired
	UserRegistrationRepository userRepo;
	
	// To get register user
	@GetMapping("register")
	public ResponseEntity<List> registeredUser(){
		return new ResponseEntity<List>(userService.findAll(),HttpStatus.OK);
	}

	@GetMapping("userid")
	public ResponseEntity<UserRegistration> userfindById(@PathVariable int id){
		return new ResponseEntity<UserRegistration>(userService.userfindById(id),HttpStatus.OK);	
	}
	
	// To Login
	@PostMapping("login")
	public ResponseEntity<UserRegistration> loginUser(@RequestBody UserRegistration user) throws Exception {
		System.out.println("user id is"+ user );		
		String tempUserId=user.getUserId();
		String tempPass= user.getPassword();
		UserRegistration loggedInUser = null;
		if(tempUserId!= null && tempPass!=null)
		{
		loggedInUser=userRepo.findByUserIdAndPassword(tempUserId,tempPass);
		System.out.println(loggedInUser);
		//System.out.println(loggedInUser.getUserId().equals(tempUserId));
		 if(loggedInUser.getUserId().equals(tempUserId) && loggedInUser.getPassword().equals(tempPass))
		{
			System.out.println("Login Done");
			return new ResponseEntity<UserRegistration>(loggedInUser,HttpStatus.OK);
		}
		}
		//return new ResponseEntity<UserRegistration>(usertemp,HttpStatus.NOT_FOUND);
		return new ResponseEntity<UserRegistration>(HttpStatus.NOT_FOUND);
	}
	
	// To register the user in db
	@PostMapping("registerUser")
	public ResponseEntity<UserRegistration> registerUser(@RequestBody UserRegistration user){
		System.out.println(user);
		return new ResponseEntity<UserRegistration>(userService.createUser(user),HttpStatus.CREATED);	
	}
	
	@PutMapping("updateUser")
	public ResponseEntity<UserRegistration> updateUsers(@RequestBody UserRegistration user){
		return new ResponseEntity<UserRegistration>(userService.updateUser(user),HttpStatus.OK);
		
	}
	
}
