package com.training.UserRegistrationwebservice.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.training.UserRegistrationwebservice.model.UserRegistration;

@Service
public interface UserRegistrationService {

	public List<UserRegistration> findAll();
	public UserRegistration createUser(UserRegistration userRegister);
	public UserRegistration userfindById(int id);
	public boolean deleteById(int id);
	public UserRegistration updateUser(UserRegistration user);
}
