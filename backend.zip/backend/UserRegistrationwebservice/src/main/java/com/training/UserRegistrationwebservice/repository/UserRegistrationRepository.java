package com.training.UserRegistrationwebservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.training.UserRegistrationwebservice.model.UserRegistration;

@Repository
public interface UserRegistrationRepository extends JpaRepository<UserRegistration,Integer> {

	UserRegistration findByUserIdAndPassword(String tempUserId, String tempPass);


}
