package com.training.UserRegistrationwebservice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import com.training.UserRegistrationwebservice.model.UserRegistration;


@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class UserControllerTest {
	@LocalServerPort
	int randomServerPort;

	@Test
	public void testGetUsers() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl2 = "http://localhost:" + randomServerPort + "/api/registerUser";
		URI uri2 = new URI(baseUrl2);

		ResponseEntity<UserRegistration> result2 = restTemplate.postForEntity(uri2,
				new UserRegistration(1, "van", "aaa"),
				UserRegistration.class);
		UserRegistration testEmp = result2.getBody();
		System.out.print(testEmp);
		System.out.print(result2.getStatusCodeValue());
		Assertions.assertEquals(201, result2.getStatusCodeValue());

		final String baseUrl = "http://localhost:" + randomServerPort + "/api/register";
		URI uri = new URI(baseUrl);
		ResponseEntity<UserRegistration[]> result = restTemplate.getForEntity(uri, UserRegistration[].class);
		System.out.println(result.getBody());// Verify request succeed
		Assertions.assertEquals(200, result.getStatusCodeValue());
//Assertions.assertEquals(true, List.of(result.getBody()).contains(testEmp));

	}

	@Test
	public void testGetUser() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl2 = "http://localhost:" + randomServerPort + "/api/login";
		URI uri2 = new URI(baseUrl2);

		ResponseEntity<UserRegistration> result2 = restTemplate.postForEntity(uri2,
				new UserRegistration(1, "van", "aaa"),UserRegistration.class);
		UserRegistration testEmp = result2.getBody();// Verify request succeed
		Assertions.assertEquals(201, result2.getStatusCodeValue());

		final String baseUrl = "http://localhost:" + randomServerPort + "/api/user?userId=" + testEmp.getUserId();
		URI uri = new URI(baseUrl);
		ResponseEntity<UserRegistration> result = restTemplate.getForEntity(uri, UserRegistration.class);
//System.out.println(result.getBody());// Verify request succeed
		Assertions.assertEquals(200, result.getStatusCodeValue());
//Assertions.assertEquals(true, List.of(result.getBody()).contains(testEmp)); // Object verification
	}

}