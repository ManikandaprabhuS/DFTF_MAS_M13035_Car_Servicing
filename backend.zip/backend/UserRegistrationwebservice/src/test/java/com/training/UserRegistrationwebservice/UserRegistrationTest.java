package com.training.UserRegistrationwebservice;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.training.UserRegistrationwebservice.model.UserRegistration;
import com.training.UserRegistrationwebservice.repository.UserRegistrationRepository;
import com.training.UserRegistrationwebservice.service.UserRegistrationServiceImpl;

@ExtendWith(MockitoExtension.class)
class UserRegistrationTest {

	@Autowired
	@InjectMocks
	UserRegistrationServiceImpl reqService;
	@Mock
	UserRegistrationRepository requesterRepo;

	@BeforeEach
	public void setup() {
	}

	@Test
	public void verifyGetRequesters() {
		UserRegistration r1 = new UserRegistration(1, "A", "aa1"); // lombok project dependency
		List<UserRegistration> reqList = List.of(r1); // new java version
		when(requesterRepo.findAll()).thenReturn(reqList);
		reqService.findAll();
		verify(requesterRepo).findAll();
	}

}