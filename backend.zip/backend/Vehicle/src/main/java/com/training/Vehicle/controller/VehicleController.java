package com.training.Vehicle.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.Vehicle.model.Vehicle;
import com.training.Vehicle.repository.VehicleRepository;
import com.training.Vehicle.service.VehicleService;

@RestController
@RequestMapping("/api/v/")
public class VehicleController {

	@Autowired
	VehicleService vehicleService;
	
	@Autowired
	VehicleRepository vehicleRepo;
	
	//get all Vehicle
	@GetMapping("vehicles")
	public List<Vehicle> getVehicle(){
	   return vehicleService.getfindAllVehicle();
	}
	
	//create Vehicle
	@PostMapping("vehicle")
	public ResponseEntity<Vehicle> create(@RequestBody Vehicle vehicle){
		return new ResponseEntity<Vehicle>( vehicleService.saveVehicle(vehicle),HttpStatus.CREATED);
	}
	
	//get Vehicle By vehicleId
	@GetMapping("vehicles/{vehicleId}")
	public ResponseEntity<Vehicle> vehicle(@PathVariable int  vehicleId){
		return new ResponseEntity<Vehicle>(vehicleService.findById(vehicleId),HttpStatus.OK) ;
	}
	
//	//getting userid whose vehicle is
	@GetMapping("vehicle/{userId}")
	public ResponseEntity<List<Vehicle>> findByuserId(@PathVariable(value="userId") int  userId){
		int tempUserId=userId;
		List<Vehicle> vehicleByUserId=vehicleService.findAllByuserId(tempUserId);
		System.out.println(vehicleByUserId);
		return new ResponseEntity<List<Vehicle>>(vehicleByUserId,HttpStatus.OK);
}
	
	
	//update Vehicle rest
	@PutMapping("vehicles/{vehicleId}")
	public ResponseEntity<Vehicle> update(@PathVariable int vehicleId,@RequestBody Vehicle vehicle){
		Vehicle v=vehicleService.findById(vehicleId);
		v.setVehicleName(vehicle.getVehicleName());
		v.setVehicleType(vehicle.getVehicleType());
		v.setVehicleColor(vehicle.getVehicleColor());
		Vehicle updateVehicle=vehicleService.save(v);
		System.out.println(updateVehicle);
		return new ResponseEntity<Vehicle>(updateVehicle,HttpStatus.OK);
	}
	
	//delete Vehicle Rest
	@DeleteMapping("vehicles/{vehicleId}")
	public ResponseEntity<Boolean> delete(@PathVariable int vehicleId){
		boolean deleteVehicle=vehicleService.delete(vehicleId);
		return new ResponseEntity<Boolean>(deleteVehicle,HttpStatus.OK);
	}
}
