package com.training.Vehicle.service;

import java.util.List;

import com.training.Vehicle.model.Vehicle;

public interface VehicleService {

	public List<Vehicle> getfindAllVehicle();
	public Vehicle saveVehicle(Vehicle vehicle);
	public Vehicle findById(int vehicleId);
	public Vehicle save(Vehicle vehicle);
	public boolean delete(int vehicleId);
	public List<Vehicle> findAllByuserId(int userId);
}
