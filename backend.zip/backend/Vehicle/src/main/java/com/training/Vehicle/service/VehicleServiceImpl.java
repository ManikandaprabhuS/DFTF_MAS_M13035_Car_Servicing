package com.training.Vehicle.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.Vehicle.model.Vehicle;
import com.training.Vehicle.repository.VehicleRepository;

@Service
public class VehicleServiceImpl implements VehicleService {

	
	@Autowired
	VehicleRepository vehicleRepo;
	
	
	@Override
	public List<Vehicle> getfindAllVehicle() {
		
		return vehicleRepo.findAll();
	}

	@Override
	public Vehicle saveVehicle(Vehicle vehicle) {
		
		return vehicleRepo.save(vehicle);
	}

	@Override
	public Vehicle findById(int vehicleId) {
		
		return vehicleRepo.findById(vehicleId).get();
	}

	@Override
	public Vehicle save(Vehicle vehicle) {
		return vehicleRepo.save(vehicle);
	}

	@Override
	public boolean delete(int vehicleId) {
		vehicleRepo.deleteById(vehicleId);
		return true;
	}

	public List<Vehicle> findAllByuserId(int userId) {
		return vehicleRepo.findAllByuserId(userId);
	}



}
