package com.training.CarCenter.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder


public class CarCenter {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int centerId;
	private String centerName;
	private String centerAddress;
	private String centerAvailability;
	private int ServiceId;
	
	
	
	public int getCenterId() {
		return centerId;
	}
	public void setCenterId(int centerId) {
		this.centerId = centerId;
	}
	public String getCenterName() {
		return centerName;
	}
	public void setCenterName(String centerName) {
		this.centerName = centerName;
	}
	public String getCenterAddress() {
		return centerAddress;
	}
	public void setCenterAddress(String centerAddress) {
		this.centerAddress = centerAddress;
	}
	public String getCenterAvailability() {
		return centerAvailability;
	}
	public void setCenterAvailability(String centerAvailability) {
		this.centerAvailability = centerAvailability;
	}
	public int getServiceId() {
		return ServiceId;
	}
	public void setServiceId(int serviceId) {
		ServiceId = serviceId;
	}
	
	
	
	@Override
	public String toString() {
		return "CarCenter [centerId=" + centerId + ", centerName=" + centerName + ", centerAddress=" + centerAddress
				+ ", centerAvailability=" + centerAvailability + ", ServiceId=" + ServiceId + "]";
	}
	// admin adding part
	public CarCenter(int centerId, String centerName, String centerAddress, String centerAvailability) {
		super();
		this.centerId = centerId;
		this.centerName = centerName;
		this.centerAddress = centerAddress;
		this.centerAvailability = centerAvailability;
	}
	
	
	public CarCenter(int centerId, String centerName, String centerAddress, String centerAvailability, int serviceId) {
		super();
		this.centerId = centerId;
		this.centerName = centerName;
		this.centerAddress = centerAddress;
		this.centerAvailability = centerAvailability;
		ServiceId = serviceId;
	}
	public CarCenter() {
		super();
		
	}

	
	
	
	

}
