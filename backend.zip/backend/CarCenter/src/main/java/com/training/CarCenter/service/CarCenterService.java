package com.training.CarCenter.service;

import java.util.List;

import com.training.CarCenter.model.CarCenter;

public interface CarCenterService {

	public List<CarCenter> getfindAllCarCenter();
	public CarCenter saveCarCenter(CarCenter carcenter);
	public CarCenter findById(int centerId);
	public CarCenter save(CarCenter carcenter);
	public boolean delete(int centerId);
	
}
