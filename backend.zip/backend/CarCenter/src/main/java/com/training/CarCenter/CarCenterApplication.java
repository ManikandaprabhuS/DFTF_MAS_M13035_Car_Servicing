package com.training.CarCenter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarCenterApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarCenterApplication.class, args);
	}

}
