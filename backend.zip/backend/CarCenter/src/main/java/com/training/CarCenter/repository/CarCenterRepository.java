package com.training.CarCenter.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.training.CarCenter.model.CarCenter;

@Repository
public interface CarCenterRepository extends JpaRepository<CarCenter, Integer> {

}
