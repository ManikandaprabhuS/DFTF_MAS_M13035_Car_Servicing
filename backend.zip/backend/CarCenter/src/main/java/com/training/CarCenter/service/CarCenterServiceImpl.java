package com.training.CarCenter.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.CarCenter.model.CarCenter;
import com.training.CarCenter.repository.CarCenterRepository;

@Service
public class CarCenterServiceImpl implements CarCenterService {
	
	@Autowired
	CarCenterRepository carRepo;

	@Override
	public List<CarCenter> getfindAllCarCenter() {
		
		return carRepo.findAll();
	}

	@Override
	public CarCenter saveCarCenter(CarCenter carcenter) {
		
		return carRepo.save(carcenter);
	}

	@Override
	public CarCenter findById(int centerId) {
		
		return carRepo.findById(centerId).get();
	}

	@Override
	public CarCenter save(CarCenter carcenter) {
		
		return carRepo.save(carcenter);
	}

	@Override
	public boolean delete(int centerId) {
		carRepo.deleteById(centerId);
		return true;
	}

}
