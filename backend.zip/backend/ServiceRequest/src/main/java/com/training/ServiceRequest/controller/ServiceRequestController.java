package com.training.ServiceRequest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.ServiceRequest.model.ServiceRequest;
import com.training.ServiceRequest.repository.ServiceRequestRepository;
import com.training.ServiceRequest.service.ServiceRequestService;

@RestController
@RequestMapping("/api/sr/")
public class ServiceRequestController {
	
	@Autowired
	ServiceRequestService servicerequestService;

	//get all ServiceRequest
		@GetMapping("servicerequests")
		public List<ServiceRequest> getAllServiceRequest(){
		   return servicerequestService.getfindAllServiceRequest();
		}
		
		//get all ServiceRequest by userId
		@GetMapping("pendingrequest/{userId}")
		public ResponseEntity<List<ServiceRequest>> getAllServiceRequestByUserId(@PathVariable(value="userId") int userId){
			List<ServiceRequest> requestService=servicerequestService.findByuserId(userId);
			System.out.println(requestService);
		   return  new ResponseEntity<List<ServiceRequest>>(requestService,HttpStatus.OK) ;
		}
		//get all ServiceRequest by deliveryBoyName
		@GetMapping("approve/{deliveryBoyName}")
		public ResponseEntity<List<ServiceRequest>> getAllServiceRequestBydeliveryBoyname(@PathVariable (value="deliveryBoyName") String deliveryBoyName){
			List<ServiceRequest> requestService=servicerequestService.findBydeliveryBoyName(deliveryBoyName);
			System.out.println(requestService);
		   return  new ResponseEntity<List<ServiceRequest>>(requestService,HttpStatus.OK) ;
		}
		
	//create ServiceRequest
	@PostMapping("servicerequest")
	public ResponseEntity<ServiceRequest> create(@RequestBody ServiceRequest servicerequest){
		System.out.println(servicerequest);
		ServiceRequest service=servicerequestService.saveServiceRequest(servicerequest);
		System.out.println(service);
		return new ResponseEntity<ServiceRequest>( service,HttpStatus.CREATED);
	}	

	
	//get ServiceRequest By serviceId
		@GetMapping("servicerequests/{serviceId}")
		public ResponseEntity<ServiceRequest> servicerequest(@PathVariable int serviceId){
			return new ResponseEntity<ServiceRequest>(servicerequestService.findById(serviceId),HttpStatus.OK) ;
		}
		
		
	//update ServiceRequest rest
	@PutMapping("servicerequests")
	public ResponseEntity<ServiceRequest> update(@RequestBody ServiceRequest servicerequest){
		ServiceRequest updateService=servicerequestService.save(servicerequest);
		System.out.println(updateService);
		return new ResponseEntity<ServiceRequest>(updateService,HttpStatus.OK);
	}	
	
	
	//delete ServiceRequest Rest
	@DeleteMapping("servicerequests/{serviceId}")
	public ResponseEntity<Boolean> delete(@PathVariable int serviceId){
		boolean deleteService=servicerequestService.delete(serviceId);
		return new ResponseEntity<Boolean>(deleteService,HttpStatus.OK);
	}
	
}
