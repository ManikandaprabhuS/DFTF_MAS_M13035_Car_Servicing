package com.training.ServiceRequest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.ServiceRequest.model.ServiceRequest;
import com.training.ServiceRequest.repository.ServiceRequestRepository;

@Service
public class ServiceRequestServiceImpl implements ServiceRequestService {
	
	@Autowired
	ServiceRequestRepository servicerequestRepo;
	
	@Override
	public List<ServiceRequest> getfindAllServiceRequest() {
		
		return servicerequestRepo.findAll();
	}

	@Override
	public ServiceRequest saveServiceRequest(ServiceRequest servicerequest) {
		
		return servicerequestRepo.save(servicerequest);
	}

	@Override
	public ServiceRequest findById(int serviceId) {
		
		return servicerequestRepo.findById(serviceId).get();
	}

	@Override
	public ServiceRequest save(ServiceRequest servicerequest) {
		
		return servicerequestRepo.save(servicerequest);
	}

	@Override
	public boolean delete(int serviceId) {
		servicerequestRepo.deleteById(serviceId);
		return true;
	}

	public List<ServiceRequest> findByuserId(int userId) {
		
		return servicerequestRepo.findByuserId(userId);
	}

	@Override
	public List<ServiceRequest> findBydeliveryBoyName(String delieveryBoyName) {
		return servicerequestRepo.findBydeliveryBoyName(delieveryBoyName);
	}

}
