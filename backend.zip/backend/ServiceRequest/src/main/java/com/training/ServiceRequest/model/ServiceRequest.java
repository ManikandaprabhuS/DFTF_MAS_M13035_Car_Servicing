package com.training.ServiceRequest.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class ServiceRequest {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int serviceId;
	private String serviceType;
	private String serviceStartDate;
	private String serviceEndDate;
	private String bookedDate;
	private float estimatedCost;
	@Column(columnDefinition= "varchar(10) default 'pending'")
	private String serviceStatus="pending";
	private String carCenterName;
	private String deliveryBoyName;
	private String deliveryBoyPhoneNumber;
	private int userId;
	private String userFirstName;
	
	
	public String getUserFirstName() {
		return userFirstName;
	}
	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getServiceStartDate() {
		return serviceStartDate;
	}
	public void setServiceStartDate(String serviceStartDate) {
		this.serviceStartDate = serviceStartDate;
	}
	public String getServiceEndDate() {
		return serviceEndDate;
	}
	public void setServiceEndDate(String serviceEndDate) {
		this.serviceEndDate = serviceEndDate;
	}
	public String getBookedDate() {
		return bookedDate;
	}
	public void setBookedDate(String bookedDate) {
		this.bookedDate = bookedDate;
	}
	public float getEstimatedCost() {
		return estimatedCost;
	}
	public void setEstimatedCost(float estimatedCost) {
		this.estimatedCost = estimatedCost;
	}
	public String getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	public String getCarCenterName() {
		return carCenterName;
	}
	public void setCarCenterName(String carCenterName) {
		this.carCenterName = carCenterName;
	}
	public String getDeliveryBoyName() {
		return deliveryBoyName;
	}
	public void setDeliveryBoyName(String deliveryBoyName) {
		this.deliveryBoyName = deliveryBoyName;
	}
	public String getDeliveryBoyPhoneNumber() {
		return deliveryBoyPhoneNumber;
	}
	public void setDeliveryBoyPhoneNumber(String deliveryBoyPhoneNumber) {
		this.deliveryBoyPhoneNumber = deliveryBoyPhoneNumber;
	}
	
	
	@Override
	public String toString() {
		return "ServiceRequest [serviceId=" + serviceId + ", serviceType=" + serviceType + ", serviceStartDate="
				+ serviceStartDate + ", serviceEndDate=" + serviceEndDate + ", bookedDate=" + bookedDate
				+ ", estimatedCost=" + estimatedCost + ", serviceStatus=" + serviceStatus + ", carCenterName="
				+ carCenterName + ", deliveryBoyName=" + deliveryBoyName + ", deliveryBoyPhoneNumber="
				+ deliveryBoyPhoneNumber + ", userId=" + userId + ", userFirstName=" + userFirstName + "]";
	}
	public ServiceRequest(int serviceId, String serviceType, String serviceStartDate, String serviceEndDate,
			String bookedDate, float estimatedCost, String serviceStatus, String carCenterName,String deliveryBoyPhoneNumber,String
			deliveryBoyName,int userId,String userFirstName) {
		super();
		this.serviceId = serviceId;
		this.serviceType = serviceType;
		this.serviceStartDate = serviceStartDate;
		this.serviceEndDate = serviceEndDate;
		this.bookedDate = bookedDate;
		this.estimatedCost = estimatedCost;
		this.serviceStatus = "pending";
		this.carCenterName=carCenterName;
		this.deliveryBoyName=deliveryBoyName;
		this.deliveryBoyPhoneNumber=deliveryBoyPhoneNumber;
		this.userId = userId;
		this.userFirstName=userFirstName;
		
	}
	// admin updating property
	public ServiceRequest(String serviceType, String serviceStartDate, String serviceEndDate, String bookedDate,
			float estimatedCost, String serviceStatus, String carCenterName, String userFirstName) {
		super();
		this.serviceType = serviceType;
		this.serviceStartDate = serviceStartDate;
		this.serviceEndDate = serviceEndDate;
		this.bookedDate = bookedDate;
		this.estimatedCost = estimatedCost;
		this.serviceStatus = "pending";
		this.carCenterName=carCenterName;
		this.userFirstName=userFirstName;
	}
	// for booking 
	public ServiceRequest(String serviceType, String serviceStartDate,String serviceStatus, String serviceEndDate, String bookedDate,int userId, String userFirstName) {
		super();
		this.serviceType = serviceType;
		this.serviceStartDate = serviceStartDate;
		this.serviceEndDate = serviceEndDate;
		this.bookedDate = bookedDate;
		this.userId = userId;
		this.serviceStatus="pending";
		this.userFirstName=userFirstName;
	}
	
	
	public ServiceRequest() {
		super();
		
	}
	
	
	
}
