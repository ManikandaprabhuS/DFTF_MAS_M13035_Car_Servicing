package com.training.ServiceRequest.service;

import java.util.List;

import com.training.ServiceRequest.model.ServiceRequest;

public interface ServiceRequestService {
	
	public List<ServiceRequest> getfindAllServiceRequest();
	public ServiceRequest saveServiceRequest(ServiceRequest servicerequest);
	public ServiceRequest findById(int serviceId);
	public ServiceRequest save(ServiceRequest servicerequest);
	public boolean delete(int serviceId);
	public List<ServiceRequest> findByuserId(int userId);
	public List<ServiceRequest> findBydeliveryBoyName(String delieveryBoyName);

}
